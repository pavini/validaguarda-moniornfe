Monitor NFe - ValidaTech Solutions
=================================

INSTALAÇÃO:
1. Execute install.bat como Administrador
2. Procure "Monitor NFe" no Menu Iniciar

USO:
- Configure as pastas de monitoramento
- Insira seu token ValidaTech
- Inicie o monitoramento automático

SUPORTE:
https://validatech.com.br

DESINSTALAÇÃO:
Execute uninstall.bat
